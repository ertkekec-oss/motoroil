"use client";

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import { ScatterChart, Scatter, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, ReferenceLine, ZAxis } from 'recharts';
import { HelpCircle, CheckCircle2, ArrowRight, AlertTriangle, AlertCircle, MoveRight, DollarSign, Package, Users, Settings } from 'lucide-react';

const InfoTooltip = ({ content, iconClassName = "w-4 h-4 text-slate-400 hover:text-slate-600" }: { content: string, iconClassName?: string }) => (
    <div className="group relative inline-flex items-center justify-center pointer-events-auto align-middle ml-1">
        <HelpCircle className={`${iconClassName} cursor-help transition-colors`} />
        <div className="opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 p-4 bg-white dark:bg-[#0f172a] border border-slate-200 dark:border-white/5 rounded-xl shadow-md text-slate-600 dark:text-slate-400 text-sm leading-relaxed z-[100] pointer-events-none font-normal text-left">
            {content}
            <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-[1px] border-[6px] border-transparent border-t-white z-10"></div>
            <div className="absolute top-full left-1/2 -translate-x-1/2 border-[7px] border-transparent border-t-slate-200"></div>
        </div>
    </div>
);

export default function CEODashboardPage() {
    const { isAuthenticated, isLoading } = useAuth();
    const router = useRouter();
    const [roleMode, setRoleMode] = useState<'CEO' | 'CFO' | 'COO' | 'Growth'>('CEO');
    const [scopeMode, setScopeMode] = useState<'Tek Şube' | 'Grup Şirketler' | 'Tüm Organizasyon'>('Tüm Organizasyon');

    // YENI EKLENEN CEO-METRICS (ESKI KOKPITTEN GELEN)
    const [data, setData] = React.useState<any>(null);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        if (!isLoading && !isAuthenticated) {
            router.push('/login');
            return;
        }

        const fetchData = async () => {
            setLoading(true);
            try {
                const res = await fetch(`/api/reports/ceo-metrics?scope=${encodeURIComponent(scopeMode)}`);
                const json = await res.json();
                setData(json);
            } catch (error) {
                console.error("CEO Metrics Error", error);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [isLoading, isAuthenticated, router, scopeMode]);

    if (isLoading || loading) {
        return (
            <div className="min-h-screen bg-slate-50 dark:bg-[#0f172a] flex items-center justify-center text-slate-800 dark:text-slate-200 font-sans">
                <div className="flex flex-col items-center gap-4">
                    <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                    <div className="font-bold text-sm tracking-widest text-slate-500 dark:text-slate-400 uppercase animate-pulse">İş Zekası Yükleniyor...</div>
                </div>
            </div>
        );
    }

    if (!data) return <div className="text-slate-800 dark:text-slate-200 p-10 font-sans font-medium">Veri alınamadı.</div>;

    const { metrics, briefing } = data;
    const { issues, warnings } = briefing || { issues: [], warnings: [] };
    const hasIssues = issues.length > 0 || warnings.length > 0;

    return (
        <div className="min-h-screen bg-slate-50 dark:bg-[#0f172a] text-slate-800 dark:text-slate-200 font-sans p-6 md:p-10 pb-24 animate-in fade-in duration-500">

            {/* 2. Soft Container Header Alanı */}
            <div className="bg-white dark:bg-[#0f172a] rounded-[20px] p-6 lg:p-8 mb-6 shadow-sm border border-slate-200 dark:border-white/5">
                <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-6">
                    {/* LEFT BLOCK: Title & Score */}
                    <div className="flex items-center gap-8">
                        <div>
                            <h1 className="text-2xl font-black tracking-tight text-slate-900 dark:text-white mb-1">
                                Strateji Merkezi
                            </h1>
                            <p className="text-slate-500 dark:text-slate-400 font-medium text-sm">
                                Şirket genel performans, risk ve öncelik analiz paneli
                            </p>
                        </div>

                        <div className="hidden md:block w-px h-12 bg-slate-200 dark:bg-slate-700/50"></div>

                        <div className="flex flex-col">
                            <div className="text-slate-500 dark:text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-0.5 flex items-center">
                                Şirket Sağlık Skoru
                                <InfoTooltip content="Nakit, stok ve kârlılık verilerinden hesaplanan genel performans göstergesi." />
                            </div>
                            <div className="flex items-baseline gap-1.5">
                                <span className={`text-3xl font-black leading-none ${data.healthScore >= 70 ? 'text-emerald-600 dark:text-emerald-400' : data.healthScore >= 40 ? 'text-amber-500' : 'text-red-600'}`}>{data.healthScore || 0}</span>
                                <span className="text-sm font-bold text-slate-400 dark:text-slate-500">/ 100</span>
                            </div>
                        </div>
                    </div>

                    {/* RIGHT BLOCK: Scope & Role Selection (Pill style matching Staff page) */}
                    <div className="flex flex-col gap-3 shrink-0 w-full xl:w-auto">
                        
                        {/* Scope Toggle */}
                        <div className="flex bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-1 items-center overflow-x-auto hide-scrollbar">
                            {(['Tek Şube', 'Grup Şirketler', 'Tüm Organizasyon'] as const).map(s => {
                                // Map display label to logical scope for internal state state if needed, but we can just use the label itself
                                const displayName = s;
                                return (
                                <button
                                    key={displayName}
                                    onClick={() => setScopeMode(displayName as any)}
                                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 flex-1 justify-center whitespace-nowrap ${scopeMode === displayName ? 'bg-white dark:bg-[#0f172a] text-blue-600 dark:text-blue-400 shadow-sm border border-slate-200 dark:border-slate-700' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200/50 dark:text-slate-400 dark:hover:text-slate-300 dark:hover:bg-white/5 border border-transparent'}`}
                                >
                                    {displayName}
                                </button>
                            )})}
                        </div>

                        {/* Role Toggle */}
                        <div className="flex bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-1 items-center overflow-x-auto hide-scrollbar">
                            {(['CEO', 'CFO', 'COO', 'Growth'] as const).map(r => {
                                const roleLabelMap: Record<string, string> = { 'CEO': 'İcra (CEO)', 'CFO': 'Finans (CFO)', 'COO': 'Operasyon (COO)', 'Growth': 'Büyüme (Growth)' };
                                const roleName = roleLabelMap[r];
                                return (
                                <button
                                    key={r}
                                    onClick={() => setRoleMode(r as any)}
                                    className={`px-5 py-2 rounded-xl text-[11px] uppercase tracking-wider font-bold transition-all flex items-center gap-1 flex-1 justify-center whitespace-nowrap ${roleMode === r ? 'bg-white dark:bg-[#0f172a] text-slate-800 dark:text-white shadow-sm border border-slate-200 dark:border-slate-700' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200/50 dark:text-slate-400 dark:hover:text-slate-300 dark:hover:bg-white/5 border border-transparent'}`}
                                >
                                    {roleName}
                                </button>
                            )})}
                        </div>

                    </div>
                </div>
            </div>

            {/* 3. DİNAMİK GÜNLÜK DURUM (Eski CEO Sayfasından Harmanlama) */}
            <div className="mb-8">
                {!hasIssues ? (
                    <div className="bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-2xl p-5 flex justify-between items-center shadow-sm">
                        <div className="flex items-center gap-3">
                            <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                            <div>
                                <div className="font-bold text-sm">Her Şey Yolunda Görünüyor</div>
                                <div className="text-xs font-medium text-emerald-600/80">Bugün için kritik bir risk, stok problemi veya finansal anomali tespit edilmedi.</div>
                            </div>
                        </div>
                        <InfoTooltip content="Bugün sistem tarafından tespit edilen kritik risk bulunmamaktadır." iconClassName="w-5 h-5 text-emerald-500 hover:text-emerald-700" />
                    </div>
                ) : (
                    <div className="space-y-3">
                        {issues.map((issue: any, idx: number) => (
                            <div key={idx} className="bg-red-50 border border-red-200 text-red-800 rounded-2xl p-5 shadow-sm flex items-center justify-between animate-in slide-in-from-top-2">
                                <div className="flex items-center gap-4">
                                    <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center shrink-0">
                                        <AlertTriangle className="w-5 h-5 text-red-600" />
                                    </div>
                                    <div>
                                        <div className="font-bold text-[15px] mb-0.5">{issue.title}</div>
                                        <div className="text-xs font-medium text-red-600/80">{issue.message}</div>
                                    </div>
                                </div>
                            </div>
                        ))}
                        {warnings.map((warn: string, idx: number) => (
                            <div key={idx} className="bg-amber-50 border border-amber-200 text-amber-800 rounded-2xl p-4 shadow-sm flex items-center gap-3">
                                <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
                                <span className="text-xs font-bold">{warn}</span>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* YENİ HARMAN: ESKİ İSTATİSTİKİ VERİLER (GERÇEK VERİ MODÜLÜ) */}
            <div className="mb-10">
                <div className="flex items-center gap-2 mb-4">
                    <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                    <h2 className="text-sm font-bold text-slate-800 dark:text-slate-200 uppercase tracking-widest">Analitik Çekirdek (Reel Metrikler)</h2>
                    <InfoTooltip content="İşletmenin anlık reel performansı." iconClassName="w-4 h-4 text-slate-400" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
                    {/* EN KÂRLI ÜRÜN */}
                    <div className="bg-white dark:bg-[#0f172a] rounded-2xl p-5 shadow-sm border border-slate-200 dark:border-white/5 group">
                        <div className="text-[11px] font-bold text-indigo-600 mb-2 uppercase flex justify-between items-center">
                            En Kârlı Ürün
                            <Package className="w-4 h-4 text-indigo-400 opacity-50 group-hover:opacity-100 transition-opacity" />
                        </div>
                        {metrics.mostProfitable ? (
                            <>
                                <div className="text-base font-black text-slate-900 dark:text-white truncate" title={metrics.mostProfitable.name}>{metrics.mostProfitable.name}</div>
                                <div className="flex items-end gap-1 mb-2">
                                    <span className="text-2xl font-black text-slate-800 dark:text-slate-200">+{Math.round(metrics.mostProfitable.roi)}%</span>
                                    <span className="text-xs text-emerald-600 font-bold mb-1">ROI</span>
                                </div>
                                <div className="text-xs font-medium text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-[#1e293b] border border-slate-100 dark:border-white/5 px-3 py-1.5 rounded-lg inline-flex items-center gap-2">
                                    <DollarSign className="w-3.5 h-3.5 text-slate-400" /> P. Başı Kâr: ₺{metrics.mostProfitable.margin.toLocaleString()}
                                </div>
                            </>
                        ) : (
                            <div className="text-sm text-slate-400 font-medium py-4">Veri yok</div>
                        )}
                    </div>

                    {/* STOK DEĞERİ */}
                    <div className="bg-white dark:bg-[#0f172a] rounded-2xl p-5 shadow-sm border border-slate-200 dark:border-white/5 group">
                        <div className="text-[11px] font-bold text-blue-600 mb-2 uppercase flex justify-between items-center">
                            Stok Maliyet Değeri
                            <Package className="w-4 h-4 text-blue-400 opacity-50 group-hover:opacity-100 transition-opacity" />
                        </div>
                        <div className="text-2xl font-black text-slate-900 dark:text-white mb-1">₺{metrics.inventoryValue?.toLocaleString()}</div>
                        <div className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-3">
                            Potansiyel: <span className="text-emerald-600 font-bold">₺{metrics.potentialRevenue?.toLocaleString()}</span>
                        </div>
                        <div className="w-full bg-slate-100 dark:bg-[#334155]/50 h-1.5 rounded-full overflow-hidden">
                            <div className="bg-blue-500 h-full" style={{ width: '60%' }}></div>
                        </div>
                    </div>

                    {/* SERVİSTE BEKLEYEN */}
                    <div className="bg-white dark:bg-[#0f172a] rounded-2xl p-5 shadow-sm border border-slate-200 dark:border-white/5 group">
                        <div className="text-[11px] font-bold text-amber-600 mb-2 uppercase flex justify-between items-center">
                            Serviste Bekleyen (WIP)
                            <Settings className="w-4 h-4 text-amber-400 opacity-50 group-hover:opacity-100 transition-opacity" />
                        </div>
                        <div className="text-2xl font-black text-slate-900 dark:text-white mb-1">₺{metrics.wipValue?.toLocaleString()}</div>
                        <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400 leading-tight mt-3">
                            Henüz faturalanmamış devam eden servis değerleri toplamı.
                        </div>
                    </div>

                    {/* PERSONEL V. & MVP */}
                    <div className=" dark:from-[#0f172a] dark:to-[#0f172a] rounded-2xl p-5 shadow-sm border border-indigo-100 group flex flex-col justify-between">
                        <div>
                            <div className="text-[11px] font-bold text-indigo-800 mb-2 uppercase flex justify-between items-center">
                                MVP Müşteri
                                <Users className="w-4 h-4 text-indigo-400 opacity-50 group-hover:opacity-100 transition-opacity" />
                            </div>
                            {metrics.mvpCustomer ? (
                                <div className="flex justify-between items-end">
                                    <div className="flex-1 pr-2">
                                        <div className="text-[15px] font-bold text-slate-900 dark:text-white truncate">{metrics.mvpCustomer.name}</div>
                                        <div className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">Satış Lideri</div>
                                    </div>
                                    <div className="text-xl font-black text-indigo-700 shrink-0">₺{metrics.mvpCustomer.total?.toLocaleString()}</div>
                                </div>
                            ) : (
                                <div className="text-sm text-slate-400 font-medium">Veri yok.</div>
                            )}
                        </div>
                        <div className="mt-4 border-t border-indigo-100/60 pt-3 flex justify-between items-center">
                            <div className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase">Per Ciro: <span className="text-slate-800 dark:text-slate-200">₺{Math.round(metrics.revenuePerEmployee || 0).toLocaleString()}</span></div>
                            <button className="text-[10px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 transition-colors">Tümü <MoveRight className="w-3 h-3" /></button>
                        </div>
                    </div>
                </div>
            </div>

            {/* 4. Ana Kart Alanı (Light Kurumsal) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                {data.roleData && data.roleData[roleMode] && data.roleData[roleMode].map((metric: any, idx: number) => (
                    <div key={idx} className="bg-white dark:bg-[#0f172a] rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-white/5 flex flex-col justify-center animate-in fade-in zoom-in-95 duration-300">
                        <div className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-2 flex justify-between items-center w-full">
                            <span>{metric.label}</span>
                            {metric.tooltip && <InfoTooltip content={metric.tooltip} />}
                        </div>
                        <div className={`text-3xl font-black ${metric.valueColor || 'text-slate-900 dark:text-white'}`}>{metric.value}</div>
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                {/* 5. Risk Haritası */}
                <div className="bg-white dark:bg-[#0f172a] border border-slate-200 dark:border-white/5 rounded-2xl p-6 shadow-sm flex flex-col min-h-[420px]">
                    <div className="flex justify-between items-start mb-2">
                        <div>
                            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center mb-1">
                                Kriz & Darboğaz Radarı
                                <InfoTooltip content="Sol-Sağ ekseni şirket iş akışının durma ihtimalini, Alt-Üst ekseni ise şirketin yaşayacağı maddi hasar/para kaybı ihtimalini gösterir." />
                            </h2>
                            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium tracking-wide">🔴 Kırmızı: Acil Müdahale Gerekli | 🟠 Turuncu: Dikkat | 🟢 Yeşil: Olağan</p>
                        </div>
                    </div>
                    <div className="flex-1 w-full mt-4">
                        <ResponsiveContainer width="100%" height="100%">
                            <ScatterChart margin={{ top: 10, right: 10, bottom: 20, left: 20 }}>
                                <XAxis type="number" dataKey="opRisk" name="Operasyonel Aksama" tick={{ fontSize: 11 }} domain={[0, 100]} />
                                <YAxis type="number" dataKey="finRisk" name="Finansal Kayıp" tick={{ fontSize: 11 }} domain={[0, 100]} />
                                <ZAxis type="number" dataKey="z" range={[100, 800]} name="Etkilenen Hacim" />
                                <Tooltip cursor={{ strokeDasharray: '3 3' }}
                                    content={(props: any) => {
                                        const { active, payload } = props;
                                        if (active && payload && payload.length) {
                                            const data = payload[0].payload;
                                            return (
                                                <div className="bg-white dark:bg-slate-900 text-slate-800 dark:text-white p-4 rounded-xl shadow-xl text-xs font-medium border border-slate-200 dark:border-slate-700 min-w-[200px]">
                                                    <div className="font-black text-sm border-b border-slate-200 dark:border-slate-700 pb-2 mb-3 flex flex-col gap-1">
                                                        <span className="text-blue-600 dark:text-blue-400">{data.name}</span>
                                                    </div>
                                                    <div className="flex justify-between text-slate-500 dark:text-slate-400 mb-1.5"><span className="font-bold">Para Kaybetme Riski:</span> <span className="text-slate-900 dark:text-white font-black">% {data.finRisk}</span></div>
                                                    <div className="flex justify-between text-slate-500 dark:text-slate-400 mb-1.5"><span className="font-bold">İşin Aksama (Gecikme) Riski:</span> <span className="text-slate-900 dark:text-white font-black">% {data.opRisk}</span></div>
                                                </div>
                                            )
                                        }
                                        return null;
                                    }}
                                />
                                <Scatter name="Tehlike Radarı" data={data.riskData || []} fill="#8884d8">
                                    {(data.riskData || []).map((entry: any, index: number) => {
                                        const score = (entry.finRisk + entry.opRisk) / 2;
                                        let color = '#10b981'; // emerald
                                        if (score > 60) color = '#ef4444'; // red
                                        else if (score > 40) color = '#f59e0b'; // amber
                                        return <Cell key={`cell-${index}`} fill={color} opacity={0.8} />
                                    })}
                                </Scatter>
                                <ReferenceLine x={50} stroke="#e2e8f0" strokeDasharray="3 3" />
                                <ReferenceLine y={50} stroke="#e2e8f0" strokeDasharray="3 3" />
                            </ScatterChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* 6. Karar Motoru */}
                <div className="bg-white dark:bg-[#0f172a] border border-slate-200 dark:border-white/5 rounded-2xl p-6 shadow-sm flex flex-col min-h-[420px]">
                    <div className="mb-6 border-b border-slate-100 dark:border-white/5 pb-4">
                        <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center">
                            Bugün Öncelikli Aksiyonlar
                            <InfoTooltip content="Sistem tarafından analiz edilerek önerilen müdahale gerektiren işlemler." />
                        </h2>
                    </div>

                    <div className="space-y-4 flex-1 overflow-y-auto pr-2 custom-scrollbar">
                        {data.decisionQueue && data.decisionQueue.length > 0 ? data.decisionQueue.map((item: any) => (
                            <div key={item.id} className="flex flex-col p-4 rounded-xl border border-slate-200 dark:border-white/5 hover:border-slate-300 hover:shadow-md transition-all bg-white dark:bg-[#0f172a] relative">
                                <div className="mb-3">
                                    <div className="text-sm font-black text-slate-900 dark:text-white mb-1 leading-tight">{item.action}</div>
                                    <div className="text-xs font-medium text-slate-500 dark:text-slate-400">{item.reason}</div>
                                </div>

                                <div className="mb-4">
                                    <div className={`text-[10px] font-bold text-${item.color}-700 bg-${item.color}-50 px-2 py-1 rounded inline-block border border-${item.color}-200`}>
                                        {item.impact}
                                    </div>
                                </div>

                                <div className="flex gap-2 w-full mt-auto">
                                    <button className="flex-1 px-3 py-2 bg-slate-900 text-white rounded-lg text-xs font-bold hover:bg-slate-800 transition-colors shadow-sm flex justify-center items-center gap-1.5 focus:ring-2 focus:ring-slate-900 focus:ring-offset-1">
                                        Operasyona Git <ArrowRight className="w-3.5 h-3.5" />
                                    </button>
                                    <button className="px-4 py-2 bg-slate-100 dark:bg-[#334155]/50 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-bold hover:bg-slate-200 transition-colors border border-slate-200 dark:border-white/5">
                                        Onayla
                                    </button>
                                    <button className="px-4 py-2 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:bg-[#1e293b] rounded-lg text-xs font-semibold transition-colors">
                                        Sonra
                                    </button>
                                </div>
                            </div>
                        )) : (
                            <div className="text-sm text-slate-500 font-medium p-4 border border-slate-200 dark:border-slate-800 rounded-xl bg-slate-50 dark:bg-slate-900/50">
                                Tüm süreçler planlandığı gibi ilerliyor. Aktif edilecek öncelikli karar bulunamadı.
                            </div>
                        )}
                    </div>
                </div>
            </div>

        </div>
    );
}
