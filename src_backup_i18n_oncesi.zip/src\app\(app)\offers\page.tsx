"use client";

import { useState, useMemo, useEffect } from 'react';
import { useModal } from '@/contexts/ModalContext';
import { useInventory } from '@/contexts/InventoryContext';
import { useCRM } from '@/contexts/CRMContext';
import { useApp } from '@/contexts/AppContext';
import OfferList from '@/components/OfferList';
import OfferForm from '@/components/OfferForm';
import OfferPreviewModal from '@/components/modals/OfferPreviewModal';

export default function OffersPage() {
    const { showSuccess, showError } = useModal();
    const { branches } = useApp();
    const [activeTab, setActiveTab] = useState<'list' | 'create' | 'edit'>('list');
    const [editingOffer, setEditingOffer] = useState<any>(null);
    const [isPreviewOpen, setIsPreviewOpen] = useState(false);
    const [previewOffer, setPreviewOffer] = useState<any>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('All');
    const [offers, setOffers] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    const fetchOffers = async () => {
        setIsLoading(true);
        try {
            const res = await fetch('/api/offers');
            const data = await res.json();
            if (data.success) {
                setOffers(data.quotes || data.offers || []);
            }
        } catch (error) {
            console.error('Fetch error:', error);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchOffers();
        
        if (typeof window !== 'undefined') {
            const params = new URLSearchParams(window.location.search);
            const customerId = params.get('customerId');
            const serviceId = params.get('serviceId');
            
            if (customerId) {
                setEditingOffer({ customerId, serviceId, description: serviceId ? 'İlgili teknik servis kaydı için oluşturulmuş teklif.' : '' });
                setActiveTab('create');
            }
        }
    }, []);

    const stats = useMemo(() => {
        const total = offers.length;
        const accepted = offers.filter(q => q.status === 'ACCEPTED' || q.status === 'CONVERTED_TO_ORDER').length;
        const pending = offers.filter(q => q.status === 'PENDING_APPROVAL' || q.status === 'SENT').length;
        const totalVal = offers.reduce((acc, q) => acc + Number(q.grandTotal || q.totalAmount || 0), 0);
        const convRate = total > 0 ? (accepted / total) * 100 : 0;

        return { total, accepted, pending, totalVal, convRate };
    }, [offers]);

    const handleSave = async (data: any) => {
        try {
            const url = editingOffer ? `/api/offers/${editingOffer.id}` : '/api/offers';
            const method = editingOffer ? 'PUT' : 'POST';

            const res = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            const json = await res.json();
            if (json.success) {
                showSuccess('Başarılı', editingOffer ? 'Teklif güncellendi' : 'Teklif oluşturuldu');
                setActiveTab('list');
                setEditingOffer(null);
                fetchOffers();
            } else {
                showError('Hata', json.error);
            }
        } catch (error) {
            showError('Hata', 'İşlem sırasında bir hata oluştu');
        }
    };

    const handleEdit = (offer: any) => {
        setEditingOffer(offer);
        setActiveTab('edit');
    };

    const handlePreview = (offer: any) => {
        setPreviewOffer(offer);
        setIsPreviewOpen(true);
    };

    return (
        <div className="p-4 sm:p-6 pb-32 animate-fade-in-up">
            <div className="flex flex-col lg:flex-row justify-between items-end gap-6 mb-6 pb-6 border-b border-slate-200 dark:border-white/10">
                <div className="flex-1">
                    <h1 className="text-[20px] sm:text-[22px] font-semibold text-slate-900 dark:text-white mb-1 tracking-tight">
                        Teklif Yönetimi
                    </h1>
                    <p className="text-[13px] text-slate-500 font-medium">B2B Ticari Teklif Motoru & Sözleşme Taslakları</p>
                </div>
            </div>

            {activeTab === 'list' && (
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
                    <div className="flex flex-1 items-center gap-3 w-full sm:w-auto max-w-2xl">
                        <div className="relative w-full sm:w-80">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                </svg>
                            </span>
                            <input
                                type="text"
                                placeholder="Teklif no veya müşteri ara..."
                                className="w-full h-[40px] bg-white dark:bg-[#0f172a] border border-slate-200 dark:border-white/10 pl-9 pr-4 rounded-lg text-[13px] outline-none transition-colors focus:border-blue-500"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>
                        <div className="relative w-40">
                            <select
                                className="w-full h-[40px] pr-8 pl-3 rounded-lg border border-slate-200 dark:border-white/10 text-[13px] outline-none cursor-pointer focus:border-blue-500 transition-colors appearance-none font-medium"
                                value={statusFilter}
                                onChange={(e) => setStatusFilter(e.target.value)}
                            >
                                <option value="All">Tüm Durumlar</option>
                                <option value="DRAFT">Taslak</option>
                                <option value="PENDING_APPROVAL">Onay Bekliyor</option>
                                <option value="SENT">Gönderildi</option>
                                <option value="ACCEPTED">Kabul Edildi</option>
                                <option value="CONVERTED_TO_ORDER">Siparişe Dönüştü</option>
                                <option value="REJECTED">Reddedildi</option>
                            </select>
                            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 dark:text-slate-500">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                                </svg>
                            </div>
                        </div>
                    </div>

                    <button
                        onClick={() => { setEditingOffer(null); setActiveTab('create'); }}
                        className="bg-blue-600 hover:bg-blue-700 text-white h-[42px] px-5 rounded-xl text-[13px] font-medium transition-colors shadow-sm w-full sm:w-auto"
                    >
                        Yeni Teklif Oluştur
                    </button>
                </div>
            )}

            <div className="mt-4">
                {activeTab === 'list' ? (
                    <OfferList
                        onEdit={handleEdit}
                        onPreview={handlePreview}
                        initialOffers={offers}
                        isLoading={isLoading}
                        searchTerm={searchTerm}
                        statusFilter={statusFilter}
                        refreshList={fetchOffers}
                    />
                ) : (
                    <div className="animate-in fade-in slide-in-from-right-4 duration-500 max-w-6xl mx-auto">
                        <div className="flex items-center gap-4 mb-6">
                            <button
                                onClick={() => { setActiveTab('list'); setEditingOffer(null); }}
                                className="w-10 h-10 rounded-full border border-slate-200 dark:border-white/10 flex items-center justify-center hover:bg-slate-50 dark:hover:bg-white/5 transition-colors text-slate-500 disabled:opacity-50"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M9.707 14.707a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 1.414L7.414 9H15a1 1 0 110 2H7.414l2.293 2.293a1 1 0 010 1.414z" clipRule="evenodd" />
                                </svg>
                            </button>
                            <div>
                                <h2 className="text-[20px] font-semibold tracking-tight">
                                    {activeTab === 'create' ? 'Yeni Teklif Oluştur' : 'Teklifi Düzenle'}
                                </h2>
                                <p className="text-[13px] text-slate-500 mt-0.5">Ticari teklif ve maliyet analizi.</p>
                            </div>
                        </div>

                        <OfferForm
                            initialData={editingOffer}
                            onSave={handleSave}
                            onCancel={() => { setActiveTab('list'); setEditingOffer(null); }}
                        />
                    </div>
                )}
            </div>

            <OfferPreviewModal
                isOpen={isPreviewOpen}
                onClose={() => setIsPreviewOpen(false)}
                offer={previewOffer}
                branches={branches}
            />
        </div>
    );
}
